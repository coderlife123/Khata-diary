# Simple-Expense-tracker-app-
Simple expense tracker android app using Kotlin where the data is stored in the local storage of the phone.


write the item name and the price
##
<img align="center" height="500" src="https://github.com/Tanmoydeb111/Simple-Expense-tracker-app-/assets/93857388/c5d6499d-4fad-470f-8491-cda3081f612a"  />






#
select date or it will automatically select current date
#
<img align="center" height="500" src="https://github.com/Tanmoydeb111/Simple-Expense-tracker-app-/assets/93857388/8344f9f5-a00d-4f27-b45c-3953e4b1d52a"  />



#

<img align="center" height="500" src="https://github.com/Tanmoydeb111/Simple-Expense-tracker-app-/assets/93857388/30214bdb-a790-4ca7-93b7-f12250bb8205"  />

<br>





#
click on delete icon on menu bar or clicl onn clear all button to clear all the items

#
<img align="center" height="500" src="https://github.com/Tanmoydeb111/Simple-Expense-tracker-app-/assets/93857388/56b24e85-97b1-4017-9aea-8f457ac35752"  />




