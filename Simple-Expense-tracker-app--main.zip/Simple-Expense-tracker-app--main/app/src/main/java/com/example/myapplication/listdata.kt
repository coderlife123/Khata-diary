package com.example.myapplication

data class listdata(
    val item_name: String = "",
    val item_price: String = "",
    val item_date: String,
)
